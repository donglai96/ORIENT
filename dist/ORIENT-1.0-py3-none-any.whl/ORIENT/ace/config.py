# @Author : Donglai
# @Time   : 11/23/2020 11:38 PM
# @Email  : dma96@atmos.ucla.edu donglaima96@gmail.com


CONFIG ={'local_data_dir':'ace_data/',
         'real_data_dir':'real_data/',
         'remote_data_dir':'ftp://ftp.swpc.noaa.gov/pub/lists/ace/'}
