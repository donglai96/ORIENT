"""
@author Donglai Ma
@email donglaima96@gmail.com
@create date 2022-05-19 17:12:12
@modify date 2022-05-19 17:12:12
@desc put shap value into the model
"""
