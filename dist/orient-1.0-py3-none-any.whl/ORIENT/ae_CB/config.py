# @Author : Donglai
# @Time   : 1/4/2021 7:33 PM
# @Email  : dma96@atmos.ucla.edu donglaima96@gmail.com

CONFIG ={'local_data_dir':'ae_CB_data/',
         'real_data_dir':'real_data/',
         'remote_data_dir': 'http://lasp.colorado.edu/space_weather/dsttemerin/archive/'}