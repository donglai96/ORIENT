# @Author : Donglai
# @Time   : 1/4/2021 7:47 PM
# @Email  : dma96@atmos.ucla.edu donglaima96@gmail.com

CONFIG ={'local_data_dir':'dst_koyoto_data/',
         'real_data_dir':'real_data/',
         'remote_data_dir': 'http://wdc.kugi.kyoto-u.ac.jp/dstae/index.html'}